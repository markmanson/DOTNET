﻿
namespace Day_1_2
{
    // ---------------------------------------------------------------------------------------------------------------------------------------------
    //      NAME            :- Constant
    //      AUTHOR NAME     :- Shikha Malik
    //      DESCRIPTION     :- The Class Constants in Project.
    //      CREATED DATE    :- 2012/12/09
    //----------------------------------------------------------------------------------------------------------------------------------------------
    public class Constant
    {
        public const string strCONNSTR = "NorthwindConnectionString";
        public const string strEMPLOYEE = "Employee.aspx";
        public const string strSRC = "src" ;
        public const string strEMP = "Emp" ;
        public const string strDETAILS = "Details";
        public const string strDEPARTMENT = "Department.aspx";
        public const string strSELDEPQRY = " Select * From Department ";
        public const string strSELEMPQRY = "Select EName, Address, Salary From Employee ";
        public const string strERRPAGE = "Error.aspx";
        public const string strVALUE = "Value";
        public static string strControlstring;
    }
}
